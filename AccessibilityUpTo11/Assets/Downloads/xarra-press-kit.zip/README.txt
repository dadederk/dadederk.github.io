Xarra! press kit
================

Press contact: Dani Devesa Derksen-Staats
Email: hello@accessibilityUpTo11.com
Product page: https://accessibilityupto11.com/apps/xarra/
Press page: https://accessibilityupto11.com/apps/xarra/press/
App Store: https://apps.apple.com/us/app/xarra/id6759402266
Recognition: Xarra! is one of the five 2026 Gaady Award winners.
Official announcement: https://gaad.foundation/what-we-do/gaadys/winners/xarra

Xarra (pronounced "CHA-rra") comes from a Valencian/Catalan word meaning
"to chat" or "to talk". Dani is from Xàbia in the Marina Alta and is based
in London.

Xarra turns articles, books, and documents into audio with synchronized line
highlighting, so people can read, listen, or do both. It imports PDF, EPUB,
Markdown, DAISY, plain text, web pages, and other documents, and includes a
Project Gutenberg browser.

Xarra is available for iPhone (including iPhone Duo), iPad, Mac, and Apple
Vision Pro. On iPhone Duo, the library and playback controls adapt as the
available space changes. On supported systems, Siri can search the Xarra
library, Spotlight can surface documents, and Shortcuts can resume, play, or
open a reading.

The app is free to download. Four Audio Documents are always free; Premium
unlocks unlimited documents through monthly, yearly, or lifetime options,
with Family Sharing. Eligible public-sector organisations and nonprofits can
request free lifetime access for the people they support by emailing the
press contact above.

10% of subscription proceeds are donated to AMMEC, a Valencia-based nonprofit
supporting people with physical disabilities and their families:
https://www.ammec.org/

Demo video (about one minute): https://youtu.be/-fBbvx9dTus
Double Tap interview (video): https://www.youtube.com/watch?v=3JMD70vf2yY
Double Tap article: https://doubletaponair.com/indie-developer-dani-devesa-derksen-staats-launches-accessible-game-reading-app-for-apple-devices/

The nine screenshots are full-resolution images for editorial coverage
of Xarra. The files are named by platform and subject. Icons are provided
as 1024, 512, and 256 pixel PNGs. The app icon was designed by illustrator
Raúl Gil: https://raul-gil.com/

Four full-resolution, 6000 x 4000 pixel photographs show Xarra on iPhone.
They were taken by Dani along the Thames Path in Hammersmith, London:
- xarra-thames-path-close-up.jpg: Xarra's reader beside the River Thames.
- xarra-thames-path-airpods.jpg: Xarra and an AirPods case.
- xarra-thames-path-dark-mode.jpg: Xarra's reader in Dark Mode.
- xarra-thames-path-wide.jpg: a wider riverside view of the reader.

The 1920 x 1080 xarra-2-0-app-store-event-card.png is Xarra! 2.0 artwork.
It is an AI-assisted composite based on Xarra screen captures, not a direct
app screenshot.

The 1672 x 941 xarra-gaady-award-2026-card.png is campaign artwork combining
Xarra's library and reader with its 2026 Gaady Award recognition and the
official Gaadys logo. It is suitable for editorial coverage of the award.

These photos, screenshots, icons, and artwork may be used for
editorial coverage of Xarra. Please credit Xarra / Dani Devesa
Derksen-Staats for the photos, screenshots, and Xarra artwork; GAAD Foundation
for the Gaadys mark; and Raúl Gil for the app icon. For other formats,
interviews, or new images, contact Dani at the email above.
